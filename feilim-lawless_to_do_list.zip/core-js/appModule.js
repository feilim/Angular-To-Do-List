  /*
  Author: Feilim Lawless
  Assignment: WE4 Mobile Web Applications, DSA, AngularJS Single Page App 
  Date: 12/09/2016
  */

    //  declare a variable named toDoListApp using angular.module method
    // give the module therein (also named toDoListApp) - a dependency on the AngularJS route module ngRoute which is used to route the partial html files of the app into the area of index.html designated by the data-ng-view directive
    var toDoListApp = angular.module("toDoListApp",["ngRoute"]);

